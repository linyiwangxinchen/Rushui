import numpy as np
from core import Dan

def test_write_data_logic():
    """测试write_data函数和数据类型判断逻辑"""
    print("创建Dan实例...")
    rushui = Dan()

    print(f"Rushui实例包含 {len([attr for attr in dir(rushui) if not attr.startswith('_') and not callable(getattr(rushui, attr))])} 个属性")

    # 找出一些典型的属性进行测试
    test_attrs = []
    for attr_name in dir(rushui):
        if not attr_name.startswith('_') and not callable(getattr(rushui, attr_name)):
            attr_value = getattr(rushui, attr_name)
            test_attrs.append((attr_name, attr_value))

    print(f"\n找到 {len(test_attrs)} 个属性，显示前10个:")
    for i, (attr_name, attr_value) in enumerate(test_attrs[:10]):
        print(f"  {i+1}. {attr_name}: {type(attr_value).__name__} = {str(attr_value)[:50]}...")

    # 测试write_data函数
    from write_data import write_data

    print("\n测试write_data函数...")
    try:
        with open('test_output.txt', 'w', encoding='utf-8') as fid:
            for attr_name, attr_value in test_attrs[:10]:  # 只测试前10个属性
                # 自动判断数据类型并选择适当的导出方式
                if isinstance(attr_value, str):
                    data_type, format_type = 'single', 'STR'
                elif isinstance(attr_value, (int, float)):
                    data_type, format_type = 'single', 'FLT'
                elif isinstance(attr_value, (list, tuple)):
                    if len(attr_value) == 0:
                        data_type, format_type = 'single', 'FLT'
                    elif all(isinstance(x, (int, float)) for x in attr_value):
                        data_type, format_type = 'array1', 'FLT'
                    else:
                        data_type, format_type = 'array1', 'STR'
                elif isinstance(attr_value, np.ndarray):
                    if attr_value.ndim == 1:
                        data_type, format_type = 'array1', 'FLT'
                    elif attr_value.ndim == 2:
                        data_type, format_type = 'array2', 'FLT'
                    else:
                        data_type, format_type = 'single', 'FLT'  # 对于高维数组，暂时作为单个值处理
                else:
                    # 默认处理其他类型
                    data_type, format_type = 'single', 'FLT'

                print(f"  导出 {attr_name} (类型: {data_type}, 格式: {format_type})")
                write_data(fid, data_type, attr_name, format_type, attr_value)

        print("数据导出成功！检查 test_output.txt 文件。")

        # 显示输出文件内容
        print("\ntest_output.txt 文件内容:")
        with open('test_output.txt', 'r', encoding='utf-8') as f:
            content = f.read()
            print(content)

        print(f"\n总共导出了 {len(test_attrs[:10])} 个变量")

    except Exception as e:
        print(f"导出过程中发生错误: {e}")
        import traceback
        traceback.print_exc()

def test_manual_export():
    """手动测试write_data函数"""
    print("\n" + "="*50)
    print("手动测试write_data函数")
    print("="*50)

    from write_data import write_data

    # 测试不同类型的数据
    test_data = [
        ("test_int", 42, 'single', 'FLT'),
        ("test_float", 3.14159, 'single', 'FLT'),
        ("test_string", "Hello World", 'single', 'STR'),
        ("test_array1", [1, 2, 3, 4, 5], 'array1', 'FLT'),
        ("test_numpy_array", np.array([1.1, 2.2, 3.3]), 'array1', 'FLT'),
        ("test_2d_array", np.array([[1, 2], [3, 4]]), 'array2', 'FLT')
    ]

    with open('manual_test_output.txt', 'w', encoding='utf-8') as fid:
        for name, data, data_type, format_type in test_data:
            print(f"导出 {name}: {data} (类型: {data_type}, 格式: {format_type})")
            write_data(fid, data_type, name, format_type, data)

    print("\nmanual_test_output.txt 文件内容:")
    with open('manual_test_output.txt', 'r', encoding='utf-8') as f:
        print(f.read())

if __name__ == "__main__":
    test_write_data_logic()
    test_manual_export()