t0 = model_data['t0']
tend = model_data['tend']
dt = model_data['dt']
v0 = model_data['v0']
theta0 = model_data['theta0']
psi0 = model_data['psi0']
phi0 = model_data['phi0']
alpha0 = model_data['alpha0']
wx0 = model_data['wx0']
wy0 = model_data['wy0']
wz0 = model_data['wz0']
k_wz = model_data['k_wz']
k_theta = model_data['k_theta']
k_ps = model_data['k_ps']
k_ph = model_data['k_ph']
k_wx = model_data['k_wx']
k_wy = model_data['k_wy']
kwz = model_data['kwz']
ktheta = model_data['ktheta']
tend_under = model_data['tend_under']










