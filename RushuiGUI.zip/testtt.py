# self.model_param_widget.L_input.setValue(mp.get('L', None))
# self.model_param_widget.S_input.setValue(mp.get('S', None))
# self.model_param_widget.V_input.setValue(mp.get('V', None))
# self.model_param_widget.m_input.setValue(mp.get('m', None))
# self.model_param_widget.xc_input.setValue(mp.get('xc', None))
# self.model_param_widget.yc_input.setValue(mp.get('yc', None))
# self.model_param_widget.zc_input.setValue(mp.get('zc', None))
# self.model_param_widget.Jxx_input.setValue(mp.get('Jxx', None))
# self.model_param_widget.Jyy_input.setValue(mp.get('Jyy', None))
# self.model_param_widget.Jzz_input.setValue(mp.get('Jzz', None))
# self.model_param_widget.T_input.setValue(mp.get('T', None))
# self.model_param_widget.lk_input.setValue(mp.get('lk', None))
# self.model_param_widget.rk_input.setValue(mp.get('rk', None))
# self.model_param_widget.sgm_input.setValue(mp.get('sgm', None))
# self.model_param_widget.dyc_input.setValue(mp.get('dyc', None))
# self.model_param_widget.SGM_input.setValue(mp.get('SGM', None))
# self.model_param_widget.LW_input.setValue(mp.get('LW', None))
# self.model_param_widget.LH_input.setValue(mp.get('LH', None))
# self.model_param_widget.dkmax_input.setValue(mp.get('dkmax', None))
# self.model_param_widget.dkmin_input.setValue(mp.get('dkmin', None))
# self.model_param_widget.dk0_input.setValue(mp.get('dk0', None))
# self.model_param_widget.deltaymax_input.setValue(mp.get('deltaymax', None))
# self.model_param_widget.deltavymax_input.setValue(mp.get('deltavymax', None))
# self.model_param_widget.ddmax_input.setValue(mp.get('ddmax', None))
# self.model_param_widget.dvmax_input.setValue(mp.get('dvmax', None))
# self.model_param_widget.dthetamax_input.setValue(mp.get('dthetamax', None))
# self.model_param_widget.wzmax_input.setValue(mp.get('wzmax', None))
# self.model_param_widget.wxmax_input.setValue(mp.get('wxmax', None))
# self.model_param_widget.dphimax_input.setValue(mp.get('dphimax', None))
#
#
# self.model_param_widget.L_input.value(),
# self.model_param_widget.S_input.value(),
# self.model_param_widget.V_input.value(),
# self.model_param_widget.m_input.value(),
# self.model_param_widget.xc_input.value(),
# self.model_param_widget.yc_input.value(),
# self.model_param_widget.zc_input.value(),
# self.model_param_widget.Jxx_input.value(),
# self.model_param_widget.Jyy_input.value(),
# self.model_param_widget.Jzz_input.value(),
# self.model_param_widget.T_input.value(),
# self.model_param_widget.lk_input.value(),
# self.model_param_widget.rk_input.value(),
# self.model_param_widget.sgm_input.value(),
# self.model_param_widget.dyc_input.value(),
# self.model_param_widget.SGM_input.value(),
# self.model_param_widget.LW_input.value(),
# self.model_param_widget.LH_input.value(),
# self.model_param_widget.dkmax_input.value(),
# self.model_param_widget.dkmin_input.value(),
# self.model_param_widget.dk0_input.value(),
# self.model_param_widget.deltaymax_input.value(),
# self.model_param_widget.deltavymax_input.value(),
# self.model_param_widget.ddmax_input.value(),
# self.model_param_widget.dvmax_input.value(),
# self.model_param_widget.dthetamax_input.value(),
# self.model_param_widget.wzmax_input.value(),
# self.model_param_widget.wxmax_input.value(),
# self.model_param_widget.dphimax_input.value(),
#
#
# 'L'
# 'S'
# 'V'
# 'm'
# 'xc'
# 'yc'
# 'zc'
# 'Jxx'
# 'Jyy'
# 'Jzz'
# 'T'
# 'lk'
# 'rk'
# 'sgm'
# 'dyc'
# 'SGM'
# 'LW'
# 'LH'
# 'dkmax'
# 'dkmin'
# 'dk0'
# 'deltaymax'
# 'deltavymax'
# 'ddmax'
# 'dvmax'
# 'dthetamax'
# 'wzmax'
# 'wxmax'
# 'dphimax'
#
#
# self.sim_control_widget.t0_input.setValue(sp.get('t0', None))
# self.sim_control_widget.tend_input.setValue(sp.get('tend', None))
# self.sim_control_widget.dt_input.setValue(sp.get('dt', None))
# self.sim_control_widget.v0_input.setValue(sp.get('v0', None))
# self.sim_control_widget.theta0_input.setValue(sp.get('theta0', None))
# self.sim_control_widget.psi0_input.setValue(sp.get('psi0', None))
# self.sim_control_widget.phi0_input.setValue(sp.get('phi0', None))
# self.sim_control_widget.alpha0_input.setValue(sp.get('alpha0', None))
# self.sim_control_widget.wx0_input.setValue(sp.get('wx0', None))
# self.sim_control_widget.wy0_input.setValue(sp.get('wy0', None))
# self.sim_control_widget.wz0_input.setValue(sp.get('wz0', None))
# self.sim_control_widget.k_wz_input.setValue(sp.get('k_wz', None))
# self.sim_control_widget.k_theta_input.setValue(sp.get('k_theta', None))
# self.sim_control_widget.kwz_input.setValue(sp.get('kwz', None))
# self.sim_control_widget.ktheta_input.setValue(sp.get('ktheta', None))
# self.sim_control_widget.k_ps_input.setValue(sp.get('k_ps', None))
# self.sim_control_widget.k_ph_input.setValue(sp.get('k_ph', None))
# self.sim_control_widget.k_wx_input.setValue(sp.get('k_wx', None))
# self.sim_control_widget.k_wy_input.setValue(sp.get('k_wy', None))
# self.sim_control_widget.tend_under_input.setValue(sp.get('tend_under', None))
#
#
#
# self.sim_control_widget.t0_input.value(),
# self.sim_control_widget.tend_input.value(),
# self.sim_control_widget.dt_input.value(),
# self.sim_control_widget.v0_input.value(),
# self.sim_control_widget.theta0_input.value(),
# self.sim_control_widget.psi0_input.value(),
# self.sim_control_widget.phi0_input.value(),
# self.sim_control_widget.alpha0_input.value(),
# self.sim_control_widget.wx0_input.value(),
# self.sim_control_widget.wy0_input.value(),
# self.sim_control_widget.wz0_input.value(),
# self.sim_control_widget.k_wz_input.value(),
# self.sim_control_widget.k_theta_input.value(),
# self.sim_control_widget.kwz_input.value(),
# self.sim_control_widget.ktheta_input.value(),
# self.sim_control_widget.k_ps_input.value(),
# self.sim_control_widget.k_ph_input.value(),
# self.sim_control_widget.k_wx_input.value(),
# self.sim_control_widget.k_wy_input.value(),
# self.sim_control_widget.tend_under_input.value(),
#
#
# t0
# tend
# dt
# v0
# theta0
# psi0
# phi0
# alpha0
# wx0
# wy0
# wz0
# k_wz
# k_theta
# kwz
# ktheta
# k_ps
# k_ph
# k_wx
# k_wy
# tend_under
#
#
# L
# S
# V
# m
# xc
# yc
# zc
# Jxx
# Jyy
# Jzz
# T
# lk
# rk
# sgm
# dyc
# SGM
# LW
# LH
# dkmax
# dkmin
# dk0
# deltaymax
# deltavymax
# ddmax
# dvmax
# dthetamax
# wzmax
# wxmax
# dphimax
#
#
# t0, _, _ = read_data('input.txt', 't0')
# tend, _, _ = read_data('input.txt', 'tend')
# dt, _, _ = read_data('input.txt', 'dt')
# v0, _, _ = read_data('input.txt', 'v0')
# theta0, _, _ = read_data('input.txt', 'theta0')
# psi0, _, _ = read_data('input.txt', 'psi0')
# phi0, _, _ = read_data('input.txt', 'phi0')
# alpha0, _, _ = read_data('input.txt', 'alpha0')
# wx0, _, _ = read_data('input.txt', 'wx0')
# wy0, _, _ = read_data('input.txt', 'wy0')
# wz0, _, _ = read_data('input.txt', 'wz0')
# k_wz, _, _ = read_data('input.txt', 'k_wz')
# k_theta, _, _ = read_data('input.txt', 'k_theta')
# kwz, _, _ = read_data('input.txt', 'kwz')
# ktheta, _, _ = read_data('input.txt', 'ktheta')
# k_ps, _, _ = read_data('input.txt', 'k_ps')
# k_ph, _, _ = read_data('input.txt', 'k_ph')
# k_wx, _, _ = read_data('input.txt', 'k_wx')
# k_wy, _, _ = read_data('input.txt', 'k_wy')
# tend_under, _, _ = read_data('input.txt', 'tend_under')
# L, _, _ = read_data('input.txt', 'L')
# S, _, _ = read_data('input.txt', 'S')
# V, _, _ = read_data('input.txt', 'V')
# m, _, _ = read_data('input.txt', 'm')
# xc, _, _ = read_data('input.txt', 'xc')
# yc, _, _ = read_data('input.txt', 'yc')
# zc, _, _ = read_data('input.txt', 'zc')
# Jxx, _, _ = read_data('input.txt', 'Jxx')
# Jyy, _, _ = read_data('input.txt', 'Jyy')
# Jzz, _, _ = read_data('input.txt', 'Jzz')
# T, _, _ = read_data('input.txt', 'T')
# lk, _, _ = read_data('input.txt', 'lk')
# rk, _, _ = read_data('input.txt', 'rk')
# sgm, _, _ = read_data('input.txt', 'sgm')
# dyc, _, _ = read_data('input.txt', 'dyc')
# SGM, _, _ = read_data('input.txt', 'SGM')
# LW, _, _ = read_data('input.txt', 'LW')
# LH, _, _ = read_data('input.txt', 'LH')
# dkmax, _, _ = read_data('input.txt', 'dkmax')
# dkmin, _, _ = read_data('input.txt', 'dkmin')
# dk0, _, _ = read_data('input.txt', 'dk0')
# deltaymax, _, _ = read_data('input.txt', 'deltaymax')
# deltavymax, _, _ = read_data('input.txt', 'deltavymax')
# ddmax, _, _ = read_data('input.txt', 'ddmax')
# dvmax, _, _ = read_data('input.txt', 'dvmax')
# dthetamax, _, _ = read_data('input.txt', 'dthetamax')
# wzmax, _, _ = read_data('input.txt', 'wzmax')
# wxmax, _, _ = read_data('input.txt', 'wxmax')
# dphimax, _, _ = read_data('input.txt', 'dphimax')
#
#
# 't0': t0,
# 'tend': tend,
# 'dt': dt,
# 'v0': v0,
# 'theta0': theta0,
# 'psi0': psi0,
# 'phi0': phi0,
# 'alpha0': alpha0,
# 'wx0': wx0,
# 'wy0': wy0,
# 'wz0': wz0,
# 'k_wz': k_wz,
# 'k_theta': k_theta,
# 'kwz': kwz,
# 'ktheta': ktheta,
# 'k_ps': k_ps,
# 'k_ph': k_ph,
# 'k_wx': k_wx,
# 'k_wy': k_wy,
# 'tend_under': tend_under,
# 'L': L,
# 'S': S,
# 'V': V,
# 'm': m,
# 'xc': xc,
# 'yc': yc,
# 'zc': zc,
# 'Jxx': Jxx,
# 'Jyy': Jyy,
# 'Jzz': Jzz,
# 'T': T,
# 'lk': lk,
# 'rk': rk,
# 'sgm': sgm,
# 'dyc': dyc,
# 'SGM': SGM,
# 'LW': LW,
# 'LH': LH,
# 'dkmax': dkmax,
# 'dkmin': dkmin,
# 'dk0': dk0,
# 'deltaymax': deltaymax,
# 'deltavymax': deltavymax,
# 'ddmax': ddmax,
# 'dvmax': dvmax,
# 'dthetamax': dthetamax,
# 'wzmax': wzmax,
# 'wxmax': wxmax,
# 'dphimax': dphimax,